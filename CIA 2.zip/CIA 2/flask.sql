use flask;
create table user(
username varchar(30),
password varchar(30),
email varchar(40));
select distinct username,password,email from user;