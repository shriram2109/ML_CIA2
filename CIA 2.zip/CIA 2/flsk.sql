use flask;
create table user(
username varchar(30),
password varchar(30));
alter table user 
drop email;
desc user;
select * from user;


